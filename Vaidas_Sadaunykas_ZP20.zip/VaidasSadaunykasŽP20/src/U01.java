
import java.util.Scanner;

public class U01 {

	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);

		System.out.println("Kiek pamokų yra pirmadienį? ");
		int pirm = reader.nextInt();

		System.out.println("Kiek pamokų yra antradienį? ");
		int antr = reader.nextInt();

		System.out.println("Kiek pamokų yra trečiadienį? ");
		int trec = reader.nextInt();

		System.out.println("Kiek pamokų yra ketvirdienį? ");
		int ketv = reader.nextInt();

		System.out.println("Kiek pamokų yra penktadienį? ");
		int penkt = reader.nextInt();

		reader.close();

		int pamokTrukme = 45;

		int pamSkaicius = pirm + antr + trec + ketv + penkt;

		int MinSkaicius = pamSkaicius * pamokTrukme;

		System.out.println("Jonuko pamokų skaičius: " + pamSkaicius);
		System.out.println("Pamokų skaičių sudaro: " + MinSkaicius + " minučių");
	}
}
