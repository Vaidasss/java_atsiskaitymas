
public class U03 {

	public static void main(String[] args) {

		int pradinis = -100; // intervalo pradžia
		int galutinis = -199; // intervalo pabaiga

		for (int a = pradinis; a >= galutinis; a = a - 3) { // ciklu for
			System.out.print(a + " "); //tarpeliui padidinti " "
		}

		System.out.println(); // kitai eilutei palyginimui

		int b = pradinis;
		while (b >= galutinis) { // ciklu while
			System.out.print(b + " ");
			b = b - 3;
		}

	}

}