
import java.util.Scanner;

public class U02  {

	public static void main(String[] args) {

		Scanner reader = new Scanner(System.in);

		System.out.print("Įveskite dėžių skaičių:  ");
		int dezes = reader.nextInt();

		System.out.print("Įveskite norimą įdėti knygų skaičių:  ");
		int knygos = reader.nextInt();

		System.out.print("Įveskite, kelios knygos telpa į dėžę:  ");
		int kiekTelp = reader.nextInt();

		int dezeje = dezes * kiekTelp;

		if (dezeje >= knygos) {
			System.out.println("Knygos telpa į dėžes."); 
		} else {
			System.out.println("Knygos netelpa į dėžes. Į dėžes netilpo " + (knygos - dezeje) + " knygos/-ų."); // lyg ir taip
		}

		reader.close();

	}

}