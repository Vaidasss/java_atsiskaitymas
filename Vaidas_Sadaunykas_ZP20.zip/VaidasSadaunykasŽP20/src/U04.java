
import java.util.Scanner;

public class U04 {

	public static void main(String[] args) {

		Scanner reader = new Scanner(System.in);

		System.out.print("Įveskite intervalo pradžią: "); // intervalo pradzia
		int pradzia = reader.nextInt();

		System.out.print("Įveskite intervalo pabaigą: "); // intervalo pabaiga
		int pabaiga = reader.nextInt();

		int sum = 0;

		for (int i = pradzia; i <= pabaiga; i++) {
			if (i % 6 == 0) {
				sum++;
			}
		}

		System.out.println("Vadybininkui reikės užsakyti: " + sum + " marškinėlių/-us.");

		reader.close();

	}

}