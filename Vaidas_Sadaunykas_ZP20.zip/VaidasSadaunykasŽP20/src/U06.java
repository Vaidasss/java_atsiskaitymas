
import java.util.Scanner;

public class U06 {

	public static void main(String[] args) {

		Scanner reader = new Scanner(System.in);

		System.out.print("Įveskite, kelis kartus Jonas mokysis?:  "); 
		int kartai = reader.nextInt();
		
		for(int a = 0; a <= kartai; a++) {
			
			System.out.print("Įveskite valandą kada pradėjo:  ");
			int pradziaAval = reader.nextInt();

			System.out.print("Įveskite minutę kada pradėjo:  ");
			int trecias = reader.nextInt();
			
		}

		********************************* NEBESPĖJU DAUGIAU ******************************
		
		
       System.out.print("Antras įvertinimas:  ");
		int antras = reader.nextInt();

		System.out.print("Trečias įvertinimas:  ");
		int trecias = reader.nextInt();

		System.out.println("Gautas rezultatas: " + gautiGeriausiIvertinima(pirmas, antras, trecias)); //

		reader.close();

	}

	private static int gautiGeriausiIvertinima(int pirmas, int antras, int trecias) {
		// TODO Auto-generated method stub
		return Math.max(pirmas, Math.max(antras, trecias));
	}

}